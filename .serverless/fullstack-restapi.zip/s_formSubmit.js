
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'ngocnhelife',
  applicationName: 'workshop',
  appUid: 'DPbfT2JPJPRn2pDbrF',
  orgUid: 'f643cfc0-8e13-4e4a-9f89-61f0ddbc371b',
  deploymentUid: '4289c89f-5088-447d-88a7-fcf34184db0f',
  serviceName: 'fullstack-restapi',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'fullstack-restapi-dev-formSubmit', timeout: 10 };

try {
  const userHandler = require('./index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.submit, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}